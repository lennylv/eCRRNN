
#coding=utf-8
'''
    author buzhong zhang
    @since 2017.7.28
    Any problem, please contact to 20154027005@stu.suda.edu.cn
'''

import gzip
import types
import math
import cPickle
import os
import string
import numpy as np
 

 
 



def  compute_q8_acc(lbl_file,pred_file):
    true_pred_count=0;all_residues=0
    lines_count=0;lbl_sequences='';pred_sequences=''
    with open(lbl_file,'r')  as fr_lbl,open(pred_file,'r') as fr_pred :
        lbl_sequences=fr_lbl.readlines()
        pred_sequences=fr_pred.readlines()

    mean_acc_per_seq=0 
    for seq in range(514):
        lbl_seq=lbl_sequences[seq*4+2].strip()
        pred_seq=pred_sequences[seq].strip()
        if (len(lbl_seq)!=len(pred_seq)):
            print lbl_seq+'\n'+pred_seq
            print("label len not equal pred sequence len,error in dataset processing")
            return 
        lines_count+=1
        print(lines_count,len(pred_seq))
        true_curr_seq=0
        for i in range(len(pred_seq)):
            
            all_residues+=1
            if lbl_seq[i]==pred_seq[i]:
                true_pred_count+=1;true_curr_seq+=1
        mean_acc_per_seq+=true_curr_seq*1.0/len(pred_seq)
        if seq==512:
            msg="513 sequences pred accruacy:%s\t"%(true_pred_count*1.0/all_residues)
            msg+="all residues%s"%(all_residues)
            print(msg)
    msg="514 sequences pred accruacy:%s\t"%(true_pred_count*1.0/all_residues)
    msg+="all residues%s"%(all_residues)
    print(msg)  
    print 'mean accuracy per sequence:\t%s'%(mean_acc_per_seq/514)      
     
        
    

   
if __name__=="__main__": 
    lbl_file='../data/cb513/cb513_fasta_label.txt'
    pred_file='../pred_out/cb513_pred.txt'
     
    
    compute_q8_acc(lbl_file,pred_file)
    