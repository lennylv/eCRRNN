
#coding=utf-8
'''
    author buzhong zhang
    @since 2017.7.28
    Any problem, please contact to 20154027005@stu.suda.edu.cn
'''

import gzip
import types
import math
import cPickle
import os
import string
import numpy as np
 

 
 



def  combine_test2018_fasta(file_dir,saved_file):
    
    if os.path.exists( file_dir)==False  :   
        return None
    files=os.listdir(file_dir)
    fasta_files=[file_dir+file for   file in files ]
    all_fastas=''
    for one_file in fasta_files:
        #obtain one label file in alphabetical order
     
        with open(one_file,'r')  as   fr_lbl :
            one_fasta=fr_lbl.readlines()
        all_fastas+= one_fasta[0]+ one_fasta[1]+'\n'
         
         
    print 'all file length: %s'%len(fasta_files)
    with open(saved_file,'w') as fw:
        fw.write(all_fastas)
     
     
        
    

   
 
if __name__=="__main__": 
    
    file_dir='../data/test2018/fasta/'
    saved_file='../data/test2018/test2018_fasta.txt'
    combine_test2018_fasta(file_dir,saved_file)
     