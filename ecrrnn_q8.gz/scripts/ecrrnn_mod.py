
#coding=utf-8
'''
    author buzhong zhang
    @since 2020.02.27
    Any problem, please contact to bzzhang@stu.suda.edu.cn
'''


import cPickle
import os
import string
import numpy as np

 

from keras import backend as K 
from keras.models import save_model,load_model
 
 

def convert_Q8_to_readable(predictedSS):
    """
    predictedSS is a 2D matrix, Proteins * residue labels
    """
    ssConvertMap = {0: 'H', 1: 'B', 2: 'E', 3: 'G', 4: 'I', 5: 'T', 6: 'S', 7: 'L', 8: ''}
    result = []
    for i in range(len(predictedSS)):
        single=[]
        for j in range(0, 700):
            single.append(ssConvertMap[predictedSS[i][j]])
        result.append( ''.join(single) )
    return result

def convert_Q3_to_readable(predictedSS):
    """
    predictedSS is a  2D matrix, Proteins * residue labels
    """
    ssConvertMap = {0: 'H', 1: 'E', 2: 'C',3: ''}
    result = []
    for i in range(len(predictedSS)):
        single=[]
        for j in range(0, 700):
            single.append(ssConvertMap[predictedSS[i][j]])
        result.append( ''.join(single) )
    return result
    
def get_q8_models(q8_model_dir):
    if os.path.exists( q8_model_dir)==False  :   
        return None
    files=os.listdir(q8_model_dir)
    #print files
    model_files=[q8_model_dir+os.sep+file for   file in files ]
    
    q8_models=[]
    for i in range(len(model_files)):
        # may be need model of source codes style
        #model=build_q8_model(model_files)
        model=load_model(model_files[i])
        q8_models.append( model )
    return q8_models

def get_q3_models(q3_model_dir):
    if os.path.exists( q3_model_dir)==False  :   
        return None
    q3_models=[]
    files=os.listdir(q3_model_dir)
    model_files=[q3_model_dir+os.sep+file for   file in files ]
    for i in range(len(model_files)):
        # may be need model of source codes style
        #model=build_q3_model(model_files)
        model=load_model(model_files[i])
        q3_models.append( model )
    return q3_models
 
 
def   write_to_file(pred_labels,new_pssmFileLists,new_all_proteins,output_file,outs_arr):
    '''
    write prediction to output file.
    '''   
    
    out_string=""
    for i in range(len(new_all_proteins)):    #  just accept 10 sequences for limited computing resources
         
        out_string+=new_pssmFileLists[i]+"\n"
        out_string+=new_all_proteins[i]+"\n" 
        out_string+=pred_labels[i]+"\n" 
        for j in range(len(new_all_proteins[i])):
            out_string+=str(outs_arr[i][j][1])+','
        out_string+='\n'
    fw=open(output_file,'w')
    fw.write(out_string)
    fw.close()


def  run_model_q3(profile_vectors ,model_q3_dir) :
 
    time_step=700
    batch_size=120
    q3_labels_len=4;
     
    #q3 predicting...
    q3_models=get_q3_models(model_q3_dir)
    out_prob_q3_ens= np.zeros( ( len(profile_vectors),time_step, q3_labels_len ), dtype=np.float32)
    for i in range(len(q3_models)):
        out_one_prob=q3_models[i].predict([profile_vectors,profile_vectors],batch_size=batch_size)   
        out_prob_q3_ens+=out_one_prob
        outs_q3_arr=out_prob_q3_ens/ len(q3_models)
    outs_q3=outs_q3_arr.argmax(axis=-1)
    q3_pred_labels=convert_Q3_to_readable(outs_q3)
     
    return  q3_pred_labels

def  run_model_q8(profile_vectors ,model_q8_dir) :
 
    time_step=700
    batch_size=120
    q8_labels_len=9
    
    #q8 predicting...
    q8_models=get_q8_models(model_q8_dir)
    out_prob_q8_ens= np.zeros( ( len(profile_vectors),time_step, q8_labels_len ), dtype=np.float32)
    for i in range(len(q8_models)):
        out_one_prob=q8_models[i].predict([profile_vectors,profile_vectors],batch_size=batch_size)   
        out_prob_q8_ens+=out_one_prob
        outs_arr=out_prob_q8_ens/ len(q8_models)
    outs=outs_arr.argmax(axis=-1)
    q8_pred_labels=convert_Q8_to_readable(outs)
     
 
    return q8_pred_labels
   
