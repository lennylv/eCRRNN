#coding=utf-8
'''
 
'''

import gzip   
import types
from decimal import *
import subprocess
import cPickle
import os
import string
import time
import math
import numpy as np

# extract sequences to one sequence...
ISOTIMEFORMAT='%Y-%m-%d %X'
resudues=['A', 'C', 'E', 'D', 'G', 'F', 'I', 'H', 'K', 'M', 'L', 'N', 'Q',\
           'P', 'S', 'R', 'T', 'W', 'V', 'Y', 'X','NoSeq']
 
def load_data_resize(dataset):
    '''
        lood data from pkl file.
    '''
    data_set = np.load(dataset ,allow_pickle=True )
    print len(data_set)
    count=0
    data=data_set.reshape((len(data_set),700,57))
 
    return data 
 
def feature_prepare(input_file):
    data_set=  load_data_resize(input_file)
     
    x_dim3=50
    y_dim3=9
    dim2 =700
    dim1=len(data_set)

    residueCount=0
    list_chains=''
    cb513_len=[]
    for i in range(dim1):
        seq_len=0
        single_chain='>TR'+str( i )+' |PDBID|CHAIN|SEQUENCE\n'   
        single_label=''
        for j in range(dim2):
           
            acid_pos=-1
            for index in range(22):
                if data_set[i][j][index]==1:
                    acid_pos=index
                    break 
            if acid_pos==20:
                continue
            if acid_pos!=21:   
                single_chain+=resudues[acid_pos]
                residueCount+=1
                seq_len+=1
            # extract label
            #'L', 'B', 'E', 'G', 'I', 'H', 'S', 'T','NoSeq'"
            #ssq8_StructDict={'H':0,'B':1,'E':2,'G':3,'I':4,'T':5,'S':6,'_':7,' ':7,'':7,'C':7}
             
            if data_set[i][j][22]==1:
                single_label+='L'
            elif data_set[i][j][23]==1:
                single_label+='B'
            elif data_set[i][j][24]==1:
                single_label+='E'
            elif data_set[i][j][25]==1:
                single_label+='G'
            elif data_set[i][j][26]==1:
                single_label+='I'
            elif data_set[i][j][27]==1:
                single_label+='H'
            elif data_set[i][j][28]==1:
                single_label+='S'
            elif data_set[i][j][29]==1:
                single_label+='T'
            else:
                single_label+=''    
        cb513_len.append(seq_len)       
        list_chains=list_chains+single_chain+'\n' +single_label +"\n\n"
    
    print ' residues count%d'%(residueCount)
    #print cb513_len

    return  list_chains

   
 
 
 

if __name__=="__main__": 
   
    in_file='../data/cb513/cb513+profile_split1.npy'
    out_file='../data/cb513/cb513_fasta_label.txt'
    list_chains=feature_prepare( in_file)
    with  open( out_file ,'wb')  as  fw:
        fw.write(list_chains)
        
     
  

 
