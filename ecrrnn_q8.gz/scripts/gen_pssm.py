# -- coding: utf-8 --
'''
    author buzhong zhang
    @since 2020.02.26
 
'''
  

import cPickle
import os
import string
import time
import math
import numpy as np
import subprocess 
 

  

def gen_PSSMs(pssmDir):
    '''
    input: PSSM files dir
    output:generated matrix like [sequences][residues][PSSM]
    '''
    if os.path.isdir( pssmDir)==False  :    #directory is not existed
        print (pssmDir, 'not exist...')
        return None
              #create directory
    pssmFileLists=os.listdir(pssmDir)
     

    #print len(pssmFileLists)
    all_PSSMs=[]
    all_proteins=[]
    for pssmPrefix in pssmFileLists:
        #prefix=pssmPrefix[:4].lower()   #upper to lower

        pssmFile=pssmDir+os.sep+pssmPrefix    #current pssm file path
        #print pssmPrefix
        residueLines,featLines=extract_one_seq(pssmFile)
        if featLines==None:
            print 'none',pssmFile
            continue
        else:
            all_PSSMs.append(featLines)
            all_proteins.append(residueLines)
            print pssmPrefix,'\t',len(featLines)
    return pssmFileLists,all_proteins,all_PSSMs

 
def gen_PSSMs_from_list(list_file,pssmDir):
    '''
    input: PSSM files dir
    output:generated matrix like [sequences][residues][PSSM]
    '''
    if os.path.isdir( pssmDir)==False  :    #directory is not existed
        print (pssmDir, 'not exist...')
        return None
              #create directory
    with open(list_file,'r')  as   fr :
            file_names=fr.readlines()
    files=[file.strip() for file in file_names]  
     

    #print len(pssmFileLists)
    all_PSSMs=[]
    all_proteins=[]
    for pssmPrefix in files:
        #prefix=pssmPrefix[:4].lower()   #upper to lower

        pssmFile=pssmDir+os.sep+pssmPrefix+'.pssm'    #current pssm file path
        #print pssmPrefix
        residueLines,featLines=extract_one_seq(pssmFile)
        if featLines==None:
            print 'none',pssmFile
            continue
        else:
            all_PSSMs.append(featLines)
            all_proteins.append(residueLines)
            print pssmPrefix,'\t',len(featLines)
    return files,all_proteins,all_PSSMs
  

def extract_lines(pssmFile):   
    fr2 =   open(pssmFile)   # pssm file open
    pssmLines=[]            #read pssp lines to memory
    if  fr2==None:    #files null
        return 
    #read pssm data ........................................
    for i in range(3):
        fr2.readline()      #skip the 3rd line. 
    while True:
        psspLine=fr2.readline()
        if  psspLine.strip()=='' or psspLine.strip()==None:
            break   #end reading.
        pssmLines.append(psspLine)  #append line.
    fr2.close()
    return   pssmLines  
 
 
 

     
def extract_one_seq(pssm_file):
    '''
    extract one sequence PSSM matrix from file
    input: filename
    output:2-dim matrix [residues][20dim PSSM + one residue]
    '''
    pssmLines=extract_lines(pssm_file)            #read pssp lines to memory
    i=0; totalResidues=len(pssmLines) 
    featLines=[]
    residueLines=''
    while i<totalResidues:
        tmp=[]
        pssmLine    =   pssmLines[i]
        pssmResidue =   pssmLine[5:7].strip()
         
        if pssmResidue=='X' or pssmResidue=='x': # ignore 'X' residue...
            i+=1
            continue
        residueLines+=pssmResidue    
        spLine=pssmLine[7:].strip('\n').split()
        for count in range(20):  
                # pssm matrix value like:-9-10-10 ............20170904
            #tmp.append(string.atoi(spLine[count]))
            item=pssmLine[9+count*3:9+(count+1)*3]  # casp12
            tmp.append(string.atoi( item ))
        tmp.append(pssmResidue)

        featLines.append(tmp)
        i+=1
    #print pssm_file,len(featLines)
    return residueLines,featLines
 
 
 #THEANO_FLAGS=mode=FAST_RUN,device=cuda1,floatX=float32  KERAS_BACKEND=theano   python 