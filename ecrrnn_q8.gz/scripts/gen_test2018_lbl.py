
#coding=utf-8
'''
    author buzhong zhang
    @since 2017.7.28
    Any problem, please contact to 20154027005@stu.suda.edu.cn
'''

import gzip
import types
import math
import cPickle
import os
import string
import numpy as np
 

 
 



def  get_test2018_lbl(test2018_file_list,label_file_dir,saved_lbl_file):
    
    lbl_file_list=[]
    with open(test2018_file_list,'r')  as   fr :
            lbl_data=fr.readlines()
    lbl_file_list=[file.strip() for file in lbl_data]        
    print 'files in the dir:',len(lbl_file_list)
    lbl_saved=[];lbl_count=0
    for one_file in lbl_file_list:
        #obtain one label file in alphabetical order
     
        with open(label_file_dir+one_file+'.ss8','r')  as   fr_lbl :
            lbl_data=fr_lbl.readlines()
        raw_labels  =lbl_data[-1].strip().split('\t')[1].strip() # labels 
        residues    =lbl_data[-2].strip().split('\t')[1].strip() #residues
         
        seq_len=int(lbl_data[-3][7:].strip())#obtain sequence length
        
        if seq_len!=len(raw_labels):
            print("error in processing.")
            return 
        q8_labels='';seq_residues='' 
        for i in range(seq_len):
            if residues[i]=='X' or residues[i]=='x':
                continue
            else:
                q8_labels+=raw_labels[i];seq_residues+=residues[i]
        if len(q8_labels)<=700:
            lbl_saved.extend([one_file,seq_residues,q8_labels])
        elif  len(q8_labels)<1400:
            bi_dim=len(q8_labels)/2
            lbl_saved.extend([one_file +' first '+str(bi_dim),
                              seq_residues[:bi_dim],q8_labels[:bi_dim] ])
            lbl_saved.extend([one_file+ ' last '+str(bi_dim),
                              seq_residues[bi_dim:],q8_labels[bi_dim:] ])
        else:
            print("the sequence is too long to process.len=%s"%len(q8_labels))
            continue
        lbl_count+=len(q8_labels)
        print '%s\t%s'%(len(q8_labels),one_file)
    print 'all labels: %s'%lbl_count
    np.savetxt(saved_lbl_file,lbl_saved,fmt='%s', delimiter='')
     
        
    

   
 
if __name__=="__main__": 
    test2018_file_list='../data/test2018/test2018_list.txt'
    label_file_dir='../data/test2018/labels/q8/'
    saved_lbl_file='../data/test2018/test2018_labels_residues.txt'
    get_test2018_lbl(test2018_file_list,label_file_dir,saved_lbl_file)
     