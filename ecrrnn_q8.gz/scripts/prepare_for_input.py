#coding=utf-8
'''
    author buzhong zhang
    @since 2020.02.27
    sequences profiles are converted into eCRRNN software input.
'''


import math
import numpy as np

ISOTIMEFORMAT='%Y-%m-%d %X'
# Physical property.
ppDict={"A":[1.28,0.05,1.0,0.31,6.11,0.42,0.23],  "G":[0.00,0.00,0.0,0.00,6.07,0.13,0.15],\
        "V":[3.67,0.14,3.0,1.22,6.02,0.27,0.49],  "L":[2.59,0.19,4.0,1.70,6.04,0.39,0.31],\
        "I":[4.19,0.19,4.0,1.80,6.04,0.30,0.45],  "F":[2.94,0.29,5.89,1.79,5.67,0.3,0.38],\
        "Y":[2.94,0.3,6.47,0.96,5.66,0.25,0.41],  "W":[3.21,0.41,8.08,2.25,5.94,0.32,0.42],\
        "T":[3.03,0.11,2.60,0.26,5.6,0.21,0.36],  "S":[1.31,0.06,1.6,-0.04,5.7,0.20,0.28],\
        "R":[2.34,0.29,6.13,-1.01,10.74,0.36,0.25],"K":[1.89,0.22,4.77,-0.99,9.99,0.32,0.27],\
        "H":[2.99,0.23,4.66,0.13,7.69,0.27,0.3],   "D":[1.6,0.11,2.78,-0.77,2.95,0.25,0.20],\
        "E":[1.56,0.15,3.78,-0.64,3.09,0.42,0.21], "N":[1.6,0.13,2.95,-0.6,6.52,0.21,0.22],\
        "Q":[1.56,0.18,3.95,-0.22,5.65,0.36,0.25], "M":[2.35,0.22,4.43,1.23,5.71,0.38,0.32],\
        "P":[2.67,0.0,2.72,0.72,6.8,0.13,0.34],    "C":[1.77,0.13,2.43,1.54,6.35,0.17,0.41],\
        "X":[0,0,0,0,0,0,0]}
phy_charaDict={
               'A':[5, 0, 2],'M':[8, 0, 2],'C':[6, 0, 2],'N':[8, 0, 4], 'D':[8,-1, 4],\
               'E':[9 ,-1, 4],'Q':[9, 0, 4], 'F':[11,0,2],'R':[11,1,4], 'G':[4, 0, 2], \
               'H':[10 ,0 ,4],'T':[7, 0, 4],'I':[8, 0, 2],'V':[7, 0, 2], 'K':[9, 1, 2],\
               'L':[8, 0, 2], 'P':[7, 0, 2],'S':[6, 0, 4],'W':[14, 0, 3],'Y':[12, 0, 3],
               'X':[0,0,0]} 

 
# our orthogonal encoding method...
orth_protein={'A':1, 'C':2, 'D':3, 'E':4, 'F':5, 'G':6, 'H':7, 'I':8, 'K':9,'L':10,'M':11, \
              'N':12,'Q':13,'P':14,'S':15,'R':16,'T':17,'W':18,'V':19,'Y':20,'NoSeq':22,'X':21,'!':21}
acids=['A' , 'C' , 'D' , 'E', 'F', 'G', 'H', 'I', 'K','L','M', \
              'N','Q','P','S','R','T','W','V','Y','NoSeq','X','!']

pro_bg_pbl={'A':0.074,'C':0.025,'D':0.054,'E':0.054,'F':0.047,'G':0.074,'H':0.026, 'I':0.068,\
         'K':0.058,'L':0.099,'M':0.025,'N':0.045,'P':0.039,'Q':0.034,'R': 0.052,'S':0.057, \
         'T':0.051,'V':0.073,'W':0.013,'Y':0.032,'X':0}
                                                                    
 



def load_one_2_vec(one_2_vec_file):
    one_2_vec=[]
    data_set = np.load(one_2_vec_file,allow_pickle=True )
    one_2_vec.extend(data_set )   
    return one_2_vec
 
def convert_to_fea50(one_2_vec_file,pssmFileLists,all_proteins,  pssm_data_set):
    """
    input: PSSM matrix, [sequence][residues][20dim PSSM, residue name]
    output: converted matrix
    """
    one_2_vec=load_one_2_vec(one_2_vec_file)  
    fea50_set=[]
    chainCount=0
    residueCount=0
    dim2=700
    new_pssmFileLists=[]
    new_all_proteins=[]
    for i in range(len(pssm_data_set)):
  
        new_protein=[]
      
        for cnt in range( len(pssm_data_set[i]) ):
            #print i,cnt,len(pssm_data_set[i])
            acid=pssm_data_set[i][cnt]
            pssmResidue=acid[20]
            if pssmResidue=='X':
                continue
            tmp=[]
            orth_pro_encode=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]  
            tmp.extend(acid[0:20])      # 20-dim PSSM
            
            #print ppDict[pssmResidue]    
            tmp.extend(ppDict[pssmResidue])         #7 dim pp
            
            
            
            orth_pro_encode[ 0:22]=one_2_vec[0][ orth_protein[ pssmResidue] ]
            # compute conservation score...2016-9-16
            Con_Score_Ri=math.log(20,2)
            for k in range(20):
                lamda=0.3176
                e=math.exp(lamda*tmp[k])*pro_bg_pbl[pssmResidue]
                Con_Score_Ri=Con_Score_Ri+e*math.log(e,2)
            
            for k in range(27): #normalize to (0,1)
                e=tmp[k]
                tmp[k]= 1.0/(1+math.exp(-1* e)) 
            tmp.append( round(Con_Score_Ri,7) )   #1-dim score
            tmp.extend(orth_pro_encode)           #22-dim sequence coding
            tmp=np.asarray(tmp, dtype=np.float32)
            new_protein.append(tmp)
            
         
        if len(new_protein)>1400 : 
            print ('sequence length more than 1400 and omited..')
            continue 
        elif len(new_protein)>dim2 and len(new_protein)<1400 :   # split into two sequences.
            bi_dim=len(new_protein)/2
            #print i,len(new_protein)
            x_tmp1=[]
            x_tmp2=[]
            for j in range(bi_dim):
                x_tmp1.append(new_protein[j])
            for j in range(len(new_protein)-bi_dim):
                x_tmp2.append(new_protein[j+bi_dim])
            fea50_set.append(x_tmp1)
            fea50_set.append(x_tmp2)
            chainCount+=2
            residueCount=residueCount+len(new_protein)
            new_pssmFileLists.append(pssmFileLists[i]+" first "+str(bi_dim))
            new_pssmFileLists.append(pssmFileLists[i]+" last "+str(bi_dim))
            new_all_proteins.append(all_proteins[i][:bi_dim])
            new_all_proteins.append(all_proteins[i][bi_dim:])
            print 'residues\t%s,residues\t%s'%(len(x_tmp1),len(x_tmp2) )
    
        else:
            fea50_set.append(new_protein)
            chainCount+=1
            residueCount=residueCount+len(new_protein)
            new_pssmFileLists.append(pssmFileLists[i] )
            new_all_proteins.append(all_proteins[i] )
            print 'residues\t%s'%len(new_protein) 
             

    #end 1st for...
  
    print 'chain count%d,residues count%d'%(chainCount,residueCount)
    return new_pssmFileLists,new_all_proteins,fea50_set
'''end def'''    
 

def align_fea_set( fea_data_set):
    '''
         trans to 3D numpy style.
    '''
    input_dim=700
    x_dim3=50
    dim1=len(fea_data_set)
    dim2=input_dim
    data_len_set=[]
    aligned_fea_set=np.zeros(shape=( dim1, dim2,x_dim3 ), dtype=np.float32)
    for i in range(len(fea_data_set)):
        data_len_set.append(len(fea_data_set[i]))
        for j in range(dim2):       
            if j<len(fea_data_set[i]):
                aligned_fea_set[i][j][0:x_dim3]=np.asarray(fea_data_set[i][j],dtype=np.float32)  
    return aligned_fea_set,data_len_set

