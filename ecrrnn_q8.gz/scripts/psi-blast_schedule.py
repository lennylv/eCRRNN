'''
	author buzhong zhang
	@since 2015.10.27
	auto run psi-blast to cumpute the PSSM Matrix.
	input file fasta style protein sequence in the directory. 
	output file is the responding pssm in the output directory.
	input dir:		./fasta
	output dir:		./pssm
'''
import subprocess
from subprocess import Popen
import os,types,sys
import time
import string

ISOTIMEFORMAT='%Y-%m-%d %X'

rootDir	=os.getcwd()  	
inDir	=rootDir+os.sep+"fasta"		#  current casp8 files directory
outDir	=rootDir+os.sep+"pssm"		#	fasta file directory

def log(msg):
	logFile=rootDir+os.sep+"blast_exe_log"
	fp=open(logFile,'a')
	now= time.strftime( ISOTIMEFORMAT, time.localtime() )	# now time 
	fp.write(now+" # "+msg+"\n")
	fp.close()
	return
'''end def''' 

def getFilePrefix(file):
	try:
		lists=string.split(file,os.sep)
		if lists==None:
			names=string.split(file,".")
			return names[0]
		else:
			names=string.split(lists[len(lists)-1],".")
			prefix= names[0]
			return prefix
	except:
		log("get file prefix name error..."+file)
		return None
'''end def'''

def blastSchedule():
	
	if os.path.isdir( inDir)==False :
		log("input file directory error")
		return None
	if os.path.exists(outDir)==False:	#mkdir output directory
		os.mkdir(outDir)	
	fileNames=os.listdir(inDir)
	os.system('export NR=/home/pub/blast/NR2/uniref90')
	for file in fileNames :
		outPrefix=getFilePrefix(file)			#get file prefix
		inFile=inDir+os.sep+file				#input fasta file
		outFile=outDir+os.sep+outPrefix+".pssm"	#output pssm file
		txtOutFile=outFile+"1"
		command="psiblast -query "+inFile+" -db /home/pub/blast/NR2/uniref90 -num_threads 8 -out_ascii_pssm "+outFile+" -num_iterations 3"
		print command  
		try:
			#subprocess.check_call(command,shell=True)
			os.system(command)
		except:
			log( "execute psiblast error!!!")
			exit(0)
	return
'''end def'''	
		
blastSchedule()	
