# -- coding: utf-8 --
'''
    author buzhong zhang
    @since 2017-07-16
     Any problem, please contact to bzzhang@stu.suda.edu.cn
'''
  

import cPickle
import os
import string
import time
import math
import numpy as np
import argparse
import shutil

from gen_pssm import  gen_PSSMs,gen_PSSMs_from_list
from prepare_for_input import convert_to_fea50,align_fea_set
from ecrrnn_mod import run_model_q8,run_model_q3, write_to_file 

model_q8_dir=''   # need setup
model_q3_dir=''   # need setup
one_2_vec_file='' # need setup 



def exec_eCRRNN(input_pssm_dir,aligned_test2018_file,pred_save_file,test_file_list,
                one_2_vec_file="../data/one-vec.dat" ,model_q8_dir='../models/q8',
                 model_q3_dir='../models/q3' ):
     
    
    pssmFileLists,all_proteins,all_PSSMs  =gen_PSSMs_from_list(test_file_list,input_pssm_dir)
    if all_PSSMs==None:
        return False
    new_pssmFileLists,new_all_proteins,  fea_data_set=convert_to_fea50(one_2_vec_file,  pssmFileLists,all_proteins,all_PSSMs)
   
    aligned_fea_set,data_len_set=align_fea_set( fea_data_set)
    
    with  open(aligned_test2018_file,'wb') as fw:
        cPickle.dump(aligned_fea_set, fw)  #test data
    
    q8_results=run_model_q8(aligned_fea_set,model_q8_dir)
    outs=zip(new_pssmFileLists,['\n']*len(new_all_proteins),new_all_proteins,['\n']*len(new_all_proteins),q8_results)
    np.savetxt(pred_save_file,outs,fmt='%s', delimiter='')
    '''
    # q3 prediction is omitted. 
    ''' 
   

def run_eval_test2018():
    one_2_vec_file="../data/one-vec.dat" 
    input_pssm_dir = '../data/test2018/pssm'   # input
    pred_save_file='../pred_out/test2018_pred_with_residues.txt'  #output
    test2018_file_list='../data/test2018/test2018_list.txt'
    model_q8_dir='../models/q8'   # need setup
    model_q3_dir='../models/q3'  # need setup 
    aligned_test2018_file='../data/test2018/test2018_pad700.pkl'
    exec_eCRRNN(input_pssm_dir,aligned_test2018_file,pred_save_file,test2018_file_list)



if __name__ == "__main__":
    run_eval_test2018()
    
# THEANO_FLAGS=mode=FAST_RUN,device=cuda0,floatX=float32  KERAS_BACKEND=theano nohup python     
