#coding=utf-8
'''
    author buzhong zhang
    @since 2020.03.18
    Any problem, please contact to 20154027005@stu.suda.edu.cn
'''

import gzip
import types
import math
import cPickle
import os
import string
import numpy as np
import theano
import keras
from keras.models import Model,save_model,load_model

def get_model_files(inDir):
    if os.path.isdir( inDir)==False  :   
        return None
               
    fileNames=os.listdir(inDir)
    res=[]
    for    file in fileNames:
        res.append(inDir+os.sep+file)    
    return res
 
def load_test_file(test_file):
     
    fw  =   open(test_file,'r') 
    data_set=cPickle.load( fw)  #test data
    fw.close()  
    return data_set

def convert_Q8_to_readable(predictedSS):
    """
    predictedSS is a 2D matrix, Proteins * residue labels
    """
    ssConvertMap = {0: 'H', 1: 'B', 2: 'E', 3: 'G', 4: 'I', 5: 'T', 6: 'S', 7: 'L', 8: ''}
     
    result = []
    for i in range(len(predictedSS)):
        single=[]
        for j in range(0, 700):
            single.append(ssConvertMap[predictedSS[i][j]])
        result.append( ''.join(single) )
    return result

def convert_Q3_to_readable(predictedSS):
    """
    predictedSS is a  2D matrix, Proteins * residue labels
    """
    ssConvertMap = {0: 'H', 1: 'E', 2: 'C'}
    result = []
    for i in range(len(predictedSS)):
        single=[]
        for j in range(0, 700):
            single.append(ssConvertMap[predictedSS[i][j]])
        result.append( ''.join(single) )
    return result
 



def  main():
    q8_models=[]  
    model_q8_dir='../models/q8'   # need setup. please decompress the model files to specified directory.
    model_q3_dir='../models/q3'  # need setup    
    labels_len =9 # 8-state. if 3-state, the values is 4.  
    # test files are 3D matrix.
    cb513_file=  '../data/cb513/cb513_profile_myfea50_pad700.npy'
    pred_save_file='../pred_out/cb513_pred.txt'
    profile_vectors,_=load_test_file(cb513_file)
    time_step=700
    batch_size=120
    model_files=get_model_files(model_q8_dir)
    for i in range(len(model_files)):
        model=load_model(model_files[i])
        q8_models.append(model)
    out_prob_ens= np.zeros( ( len(profile_vectors),time_step, labels_len ), dtype=np.float32)
    for i in range(len(model_files)):
        out_one_prob=q8_models[i].predict([profile_vectors,profile_vectors],batch_size=batch_size)   
        out_prob_ens+=out_one_prob
        outs_arr=out_prob_ens/ len(model_files)
    outs=outs_arr.argmax(axis=-1)
    pred_labels=convert_Q8_to_readable(outs)
    # out predicted results
    #print pred_labels
    np.savetxt(pred_save_file,pred_labels,fmt='%s', delimiter='')
    

   
if __name__=="__main__": 
    main()
    # THEANO_FLAGS=mode=FAST_RUN,device=cuda0,floatX=float32  KERAS_BACKEND=theano nohup python 