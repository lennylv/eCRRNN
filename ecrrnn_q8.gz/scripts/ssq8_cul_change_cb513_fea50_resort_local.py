#coding=utf-8
'''
    author buzhong zhang
    @since 2017.10.28

'''

import numpy as np

import cPickle
import os
import sys  
import math
import time
import datetime


'''
The following descriptions are selected from Jian Zhou's repository. It's helpful to transfer cb513 dataset format.

It is currently in numpy format as a (N protein x k features) matrix. You can reshape it to (N protein x 700 amino acids x 57 features) first. 
The 57 features are:
"[0,22): amino acid residues, with the order of 'A', 'C', 'E', 'D', 'G', 'F', 'I', 'H', 'K', 'M', 'L', 'N', 'Q', 'P', 'S', 'R', 'T', 'W', 'V', 'Y', 'X','NoSeq'"
"[22,31): Secondary structure labels, with the sequence of 'L', 'B', 'E', 'G', 'I', 'H', 'S', 'T','NoSeq'"
"[31,33): N- and C- terminals;"
"[33,35): relative and absolute solvent accessibility, used only for training. (absolute accessibility is thresholded at 15; relative accessibility is normalized by the largest accessibility value in a protein and thresholded at 0.15; original solvent accessibility is computed by DSSP)"
"[35,57): sequence profile. Note the order of amino acid residues is ACDEFGHIKLMNPQRSTVWXY and it is different from the order for amino acid residues"

'''
ISOTIMEFORMAT='%Y-%m-%d %X'
# Physical property.
ppDict={"A":[1.28,0.05,1.0,0.31,6.11,0.42,0.23],  "G":[0.00,0.00,0.0,0.00,6.07,0.13,0.15],\
        "V":[3.67,0.14,3.0,1.22,6.02,0.27,0.49],  "L":[2.59,0.19,4.0,1.70,6.04,0.39,0.31],\
        "I":[4.19,0.19,4.0,1.80,6.04,0.30,0.45],  "F":[2.94,0.29,5.89,1.79,5.67,0.3,0.38],\
        "Y":[2.94,0.3,6.47,0.96,5.66,0.25,0.41],  "W":[3.21,0.41,8.08,2.25,5.94,0.32,0.42],\
        "T":[3.03,0.11,2.60,0.26,5.6,0.21,0.36],  "S":[1.31,0.06,1.6,-0.04,5.7,0.20,0.28],\
        "R":[2.34,0.29,6.13,-1.01,10.74,0.36,0.25],"K":[1.89,0.22,4.77,-0.99,9.99,0.32,0.27],\
        "H":[2.99,0.23,4.66,0.13,7.69,0.27,0.3],   "D":[1.6,0.11,2.78,-0.77,2.95,0.25,0.20],\
        "E":[1.56,0.15,3.78,-0.64,3.09,0.42,0.21], "N":[1.6,0.13,2.95,-0.6,6.52,0.21,0.22],\
        "Q":[1.56,0.18,3.95,-0.22,5.65,0.36,0.25], "M":[2.35,0.22,4.43,1.23,5.71,0.38,0.32],\
        "P":[2.67,0.0,2.72,0.72,6.8,0.13,0.34],    "C":[1.77,0.13,2.43,1.54,6.35,0.17,0.41]}
phy_charaDict={
               'A':[5, 0, 2],'M':[8, 0, 2],'C':[6, 0, 2],'N':[8, 0, 4], 'D':[8,-1, 4],\
               'E':[9 ,-1, 4],'Q':[9, 0, 4], 'F':[11,0,2],'R':[11,1,4], 'G':[4, 0, 2], \
               'H':[10 ,0 ,4],'T':[7, 0, 4],'I':[8, 0, 2],'V':[7, 0, 2], 'K':[9, 1, 2],\
               'L':[8, 0, 2], 'P':[7, 0, 2],'S':[6, 0, 4],'W':[14, 0, 3],'Y':[12, 0, 3]} 
pro_bg_pbl={'A':0.074,'C':0.025,'D':0.054,'E':0.054,'F':0.047,'G':0.074,'H':0.026, 'I':0.068,\
         'K':0.058,'L':0.099,'M':0.025,'N':0.045,'P':0.039,'Q':0.034,'R': 0.052,'S':0.057, \
         'T':0.051,'V':0.073,'W':0.013,'Y':0.032,'X':0}
resudues=['A', 'C', 'E', 'D', 'G', 'F', 'I', 'H', 'K', 'M', 'L', 'N', 'Q',\
           'P', 'S', 'R', 'T', 'W', 'V', 'Y', 'X','NoSeq']
pssm22_seq={'A':0, 'C':1,  'D':2,'E':3, 'F':4,'G':5, 'H':6,'I':7, 'K':8,\
             'L':9, 'M':10, 'N':11, 'P':12,'Q':13, 'R':14,'S':15, 'T':16, 'V':17,'W':18, 'X':19, 'Y':20, 'NoSeq':21}
pssm20_seq=['A','R', 'N','D','C', 'Q', 'E','G', 'H','I', 'L','K', 'M','F','P', 'S',  'T','W', 'Y','V']
            #pssm:A  R  N  D  C  Q  E  G  H  I  L  K  M  F  P  S  T  W  Y  V 
            #this data:A C D E F G H I K L M N P Q R S T V W X Y,noseq 


# our orthogonal encoding method...
orth_protein={'A':1, 'C':2, 'D':3, 'E':4, 'F':5, 'G':6, 'H':7, 'I':8, 'K':9,'L':10,'M':11, \
              'N':12,'Q':13,'P':14,'S':15,'R':16,'T':17,'W':18,'V':19,'Y':20,'NoSeq':21,'X':22}


residue_no={"A":0,"C":1,"D":2,"E":3,"F":4,"G":5,"H":6,"I":7,"K":8,\
          "L":9,"M":10,"N":11,"P":12,"Q":13,"R":14,"S":15,"T":16,"V":17,"W":18,"Y":19}
reidues=["A","C","D","E","F","G","H","I","K",  "L","M","N","P","Q","R","S","T","V","W","Y"] 

 


    

 
def load_data_resize(dataset):
    '''
        lood data from pkl file.
    '''
    data_set = np.load(dataset ,allow_pickle=True )
    print len(data_set)
    #data=np.reshape(dataset, (514,700,57))
    count=0
    data=data_set.reshape((len(data_set),700,57))
 
    return data 
    
def change_data_mysytle(dataset,one_2_vec_file):
    '''
    default style:
    0-21     amino acid residues.
    22-30 Secondary structure labels, with the sequence of 'L', 'B', 'E', 'G', 'I', 'H', 'S', 'T','NoSeq'"
    31-32 N- and C- terminals
    33-34  relative and absolute solvent accessibility
    35-56 22bit PSSM
    Jian data order :A C D E F G H I K L M N P Q R S T V W X Y,noseq
    pssm from psi-blast:A  R  N  D  C  Q  E  G  H  I  L  K  M  F  P  S  T  W  Y  V 
    our data form:20pssm,7 dim pp,3-dim phy,1-Con_Score,22 orth_pro_encode
    '''
    one_2_vec=[]
    one_vec_set = np.load(one_2_vec_file,allow_pickle=True )
    one_2_vec.extend(one_vec_set )
    
    x_dim3=50
    y_dim3=9
    dim2 =700
    dim1=len(dataset)
     
    fea_data=[]
    label_data=[]
    chainCount=0
    residueCount=0
    residue_label_dist=[] #------------------------
    for i in range(len(reidues)):
        tmp=[] 
        tmp.append([reidues[i] ])
        tmp.append([0,0,0,0,0,0,0,0])
        residue_label_dist.append(tmp)
    #print     residue_label_dist
    for i in range(dim1):
        tmp_acid=[]
        lbl_acid=[]
        for j in range(dim2):
            x_tmp=[]
            orth_pro_encode=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0] # 22 zero.
            acid_pos=0
            for index in range(22):
                if dataset[i][j][index]==1:
                    acid_pos=index
                    break
            
            if acid_pos==20   :  # residue X, ignore it
                continue
            if  acid_pos==21 :  # residue  'no seq' 
                break
            for k in range(20):   # PSSM features formatting. transfor Jian's style to psi-blast style.
                pssm22_pos =pssm22_seq[ pssm20_seq[k] ]
                x_tmp.append( dataset[i][j][35+pssm22_pos] )
                
            x_tmp.extend(ppDict[   resudues[acid_pos] ])
            for k in range(7):   # normalize  physical properties to(0,1)
                e=x_tmp[20+k]
                x_tmp[20+k]= 1.0/(1+math.exp(-1* e)) 
             
            # compute conservation score...2016-9-16
            Con_Score_Ri = math.log(20,2)
            lamda = 0.3176
            for k in range(20):
                #remodify data...2016-12-12
                dexp=-1*math.log(1.0/x_tmp[k]-1)
                e = math.exp(lamda * dexp) * pro_bg_pbl[ pssm20_seq[k] ]
                Con_Score_Ri = Con_Score_Ri + e * math.log(e,2)
            x_tmp.append(round(Con_Score_Ri, 7))
            
            # sequence coding...
            new_pos= orth_protein[   resudues[acid_pos] ]  
            x_tmp.extend(one_2_vec[0][new_pos] )
             
            #'L', 'B', 'E', 'G', 'I', 'H', 'S', 'T','NoSeq'"
            #ssq8_StructDict={'H':0,'B':1,'E':2,'G':3,'I':4,'T':5,'S':6,'_':7,' ':7,'':7,'C':7}
            yd_tmp=[0,0,0,0,0,0,0,0,0]
            if dataset[i][j][22]==1:
                yd_tmp[7]=1
            elif dataset[i][j][23]==1:
                yd_tmp[1]=1
            elif dataset[i][j][24]==1:
                yd_tmp[2]=1
            elif dataset[i][j][25]==1:
                yd_tmp[3]=1
            elif dataset[i][j][26]==1:
                yd_tmp[4]=1
            elif dataset[i][j][27]==1:
                yd_tmp[0]=1
            elif dataset[i][j][28]==1:
                yd_tmp[6]=1
            elif dataset[i][j][29]==1:
                yd_tmp[5]=1
            else :
                yd_tmp[8]=1
            tmp_acid.append(x_tmp)
            #------------
            
            pos=residue_no[resudues[acid_pos] ]
            for cnt in range(len(yd_tmp)-1):
                residue_label_dist[pos][1][cnt] +=yd_tmp[cnt]
            
            lbl_acid.append(yd_tmp)
 
        fea_data.append(tmp_acid)
        label_data.append(lbl_acid)
        chainCount+=1
        residueCount=residueCount+len(tmp_acid)
 
            
    print len(fea_data),len(label_data),chainCount,residueCount
    #print residue_label_dist
    return fea_data,label_data

def trans_to_3D( data_set):
 
    X_Data,y_Data=data_set
    dim1=len(y_Data)
    dim2=700
    #  np.zeros
    count=0
    y_dim3=9
    x_dim3=50
    yd=np.zeros(shape=(dim1, dim2,y_dim3), dtype=np.int32)
 
    for i in range(len(y_Data)):
        for j in range(dim2):
             
            if j<len(y_Data[i]) : 
                yd[i][j][0:y_dim3]=y_Data[i][j]
                count+=1
            else:
                yd[i][j][y_dim3-1]=1
            
    #print count                 
    y_Data=yd
    
    count=0
    xd=np.zeros(shape=( dim1, dim2,x_dim3 ), dtype=np.float32)
    for i in range(len(X_Data)):
 
        for j in range(dim2):
            acid_pos=0
            if j <len(X_Data[i]):
                xd[i][j]=np.asarray(X_Data[i][j],dtype=np.float32)  

                count+=1
        
    X_Data=xd
    #print count
    return X_Data,y_Data
def compute():

    in_file= '../data/cb513/cb513+profile_split1.npy'
    out_file= '../data/cb513/cb513_profile_myfea50_pad700.npy'
    one_2_vec_file= "../data/one-vec.dat"
    
    dataset=load_data_resize(in_file)
    data=change_data_mysytle(dataset,one_2_vec_file)
    res_data=trans_to_3D(data)
    
    f3 = open(out_file, 'wb') 
     
    cPickle.dump(res_data, f3)
    f3.close() 
    
    
compute()    

 
