
#coding=utf-8
'''
    author buzhong zhang
    @since 2017.7.28
    Any problem, please contact to 20154027005@stu.suda.edu.cn
'''

import gzip
import types
import math
import cPickle
import os
import string
import numpy as np
 

 
 



def  compute_q8_acc(lbl_file,pred_file):
    true_pred_count=0;all_residues=0
    lines_count=0;lbl_sequences='';pred_sequences=''
    with open(lbl_file,'r')  as fr_lbl,open(pred_file,'r') as fr_pred :
        lbl_sequences=fr_lbl.readlines() 
        pred_sequences=fr_pred.readlines() 
    if len(lbl_sequences)/3!=len(pred_sequences)/3:
        print 'length of pred data %s is not equal to labels %s'%(len(lbl_sequences),len(pred_sequences))
    
    mean_acc_per_seq=0 
    print 'id\t\tLen\tacc\t'
    for cnt in range(len(lbl_sequences)/3):
        pred_seq_id=pred_sequences[cnt*3].strip()[:5]
        lbl_seq_id=lbl_sequences[cnt*3].strip()[:5]
        lbl_residues=lbl_sequences[cnt*3+1].strip();lbl_ssq8=lbl_sequences[cnt*3+2].strip()
        pred_residues=pred_sequences[cnt*3+1].strip();pred_ssq8=pred_sequences[cnt*3+2].strip()
        
         
        if (pred_seq_id!=lbl_seq_id and len(lbl_ssq8)!=len(pred_ssq8)):
            print cnt,len(lbl_ssq8),len(pred_ssq8)
            print("label len not equal pred sequence len,error in dataset processing")
            return 
        lines_count+=1
        
        true_curr_seq=0
        for i in range(len(pred_ssq8)):
            # 
            if lbl_residues[i]!=pred_residues[i]:
                print 'processing error, %s,%s'%(cnt,i)
                return 
            all_residues+=1
            if lbl_ssq8[i]==pred_ssq8[i]:
                true_pred_count+=1;true_curr_seq+=1
            # our pred 'L' is same with label 'C'
            if lbl_ssq8[i]=='C' and pred_ssq8[i]=='L':
                true_pred_count+=1;true_curr_seq+=1
        print '%s\t\t%s\t%s'%(pred_seq_id,len(pred_ssq8),true_curr_seq*1.0/len(pred_ssq8))
        # pred_ssq8 combined sequence id, residuese and pred ss
        mean_acc_per_seq+=true_curr_seq*1.0/len(pred_ssq8)*3  
         
    msg="sequences pred accruacy:%s\t"%(true_pred_count*1.0/all_residues)
    msg+="all residues%s"%(all_residues)
    print(msg)  
    print 'mean accuracy per sequence:\t%s'%(mean_acc_per_seq/len(lbl_sequences))      
     
        
    

   
if __name__=="__main__": 
    lbl_file='../data/test2018/test2018_labels_residues.txt'
    pred_file='../pred_out/test2018_pred_with_residues.txt'
    #pred_file='../pred_out/test2018_pred_no_orth_code.txt'
    compute_q8_acc(lbl_file,pred_file)
    